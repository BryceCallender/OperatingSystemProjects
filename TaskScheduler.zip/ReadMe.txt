Program Needed to run - VS 2019 with C++ Support. 

Need to run on a windows system do to the System("pause") command in the code. It is there for you if you want to check the trial output since the program spits out so much to the console.